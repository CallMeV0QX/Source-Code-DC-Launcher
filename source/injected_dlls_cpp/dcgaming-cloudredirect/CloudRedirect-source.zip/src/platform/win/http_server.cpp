#include "http_server.h"
#include "http_util.h"
#include "file_util.h"
#include "cloud_storage.h"
#include "log.h"

#include "miniz.h"

#include <WinSock2.h>
#include <WS2tcpip.h>
#include <iphlpapi.h>
#include <tcpmib.h>
#include <thread>
#include <chrono>
#include <atomic>
#include <mutex>
#include <memory>
#include <vector>
#include <algorithm>
#include <filesystem>
#include <fstream>
#include <unordered_map>

#pragma comment(lib, "ws2_32.lib")
#pragma comment(lib, "iphlpapi.lib")

namespace HttpServer {

static const char* stristr(const char* haystack, const char* needle) {
    if (!haystack || !needle) return nullptr;
    size_t nlen = strlen(needle);
    for (; *haystack; ++haystack) {
        if (_strnicmp(haystack, needle, nlen) == 0)
            return haystack;
    }
    return nullptr;
}

static SOCKET g_listenSock = INVALID_SOCKET;
static std::atomic<uint16_t> g_port{0};
static std::thread g_acceptThread;
static std::atomic<bool> g_running{false};
static std::string g_blobRoot; // persistent blob storage directory
static std::atomic<uint32_t> g_accountId{0}; // Steam account ID for namespace isolation
static std::atomic<int64_t> g_maxUploadBytes{256 * 1024 * 1024}; // 256 MB default, 0 = unlimited
static std::mutex g_clientMtx;

// In-memory blob fallback when disk write fails (antivirus lock, etc).
struct BlobKey {
    uint32_t accountId;
    uint32_t appId;
    std::string filename;
    bool operator==(const BlobKey& o) const {
        return accountId == o.accountId && appId == o.appId && filename == o.filename;
    }
};
struct BlobKeyHash {
    size_t operator()(const BlobKey& k) const {
        size_t h = std::hash<uint32_t>{}(k.accountId);
        h ^= std::hash<uint32_t>{}(k.appId) + 0x9e3779b9 + (h << 6) + (h >> 2);
        h ^= std::hash<std::string>{}(k.filename) + 0x9e3779b9 + (h << 6) + (h >> 2);
        return h;
    }
};
static std::mutex g_memBlobMtx;
static std::unordered_map<BlobKey, std::vector<uint8_t>, BlobKeyHash> g_memBlobs;

struct ClientSlot {
    std::thread                    thread;
    std::shared_ptr<std::atomic<bool>> done;
};
static std::vector<ClientSlot> g_clientSlots;
// High-file-count manifests (e.g. Everwind, 827 files) burst-request downloads; 16
// starved the pool and rejected connections, surfacing as a Steam cloud error.
static constexpr size_t kMaxClientThreads = 64;
// At the cap, wait this long for a slot before rejecting (backpressure).
static constexpr int    kAcceptBackpressureMaxMs = 5000;

// Decompress Steam's cloud-compression ZIP. Returns false (and leaves out untouched) on non-ZIP or failure.
static bool TryDecompressZip(const std::vector<uint8_t>& data, std::vector<uint8_t>& out) {
    if (data.size() < 4) return false;
    if (data[0] != 0x50 || data[1] != 0x4B || data[2] != 0x03 || data[3] != 0x04)
        return false;

    mz_zip_archive zip{};
    if (!mz_zip_reader_init_mem(&zip, data.data(), data.size(), 0)) {
        LOG("[HTTP] ZIP init failed: %s", mz_zip_get_error_string(mz_zip_get_last_error(&zip)));
        return false;
    }

    // Steam cloud ZIP is single-entry, inner name "z"; anything else is a game save that's natively ZIP.
    if (mz_zip_reader_get_num_files(&zip) != 1) {
        mz_zip_reader_end(&zip);
        return false;
    }
    mz_zip_archive_file_stat fstat;
    if (!mz_zip_reader_file_stat(&zip, 0, &fstat) ||
        strcmp(fstat.m_filename, "z") != 0) {
        mz_zip_reader_end(&zip);
        return false;
    }

    // Reject if declared uncompressed size exceeds 512 MB
    if (fstat.m_uncomp_size > 512ULL * 1024 * 1024) {
        LOG("[HTTP] ZIP rejected: declared size %llu", (unsigned long long)fstat.m_uncomp_size);
        mz_zip_reader_end(&zip);
        return false;
    }

    size_t uncompSize = 0;
    void* p = mz_zip_reader_extract_to_heap(&zip, 0, &uncompSize, 0);
    mz_zip_reader_end(&zip);

    if (!p) {
        LOG("[HTTP] ZIP extract failed");
        return false;
    }

    out.assign(static_cast<uint8_t*>(p), static_cast<uint8_t*>(p) + uncompSize);
    mz_free(p);
    return true;
}

// Remove finished client threads (call with g_clientMtx held)
static void PruneClientThreads() {
    std::vector<ClientSlot> alive;
    alive.reserve(g_clientSlots.size());
    for (auto& slot : g_clientSlots) {
        if (slot.done->load()) {
            if (slot.thread.joinable()) slot.thread.join();
        } else {
            alive.push_back(std::move(slot));
        }
    }
    g_clientSlots = std::move(alive);
}

// get the filesystem path for a blob: <blobRoot>/<accountId>/<appId>/<filename>
static std::string BlobPath(uint32_t accountId, uint32_t appId, const std::string& filename) {
    std::string path = g_blobRoot + std::to_string(accountId) + "\\" +
                       std::to_string(appId) + "\\" + filename;
    for (auto& c : path) { if (c == '/') c = '\\'; }
    return path;
}

// Parse "/upload/<account>/<app>/<file>" or "/download/..."; rejects "../" after URL decoding.
static bool ParseBlobPath(const char* path, const char* prefix,
                          uint32_t& accountId, uint32_t& appId, std::string& filename) {
    size_t prefixLen = strlen(prefix);
    if (strncmp(path, prefix, prefixLen) != 0) return false;

    const char* rest = path + prefixLen;
    // parse accountId (digits until next '/')
    char* slash = nullptr;
    unsigned long id = strtoul(rest, &slash, 10);
    if (!slash || *slash != '/' || id == 0) return false;

    accountId = (uint32_t)id;
    rest = slash + 1;

    // parse appId (digits until next '/')
    id = strtoul(rest, &slash, 10);
    if (!slash || *slash != '/' || id == 0) return false;
    appId = (uint32_t)id;

    std::string rawPath(slash + 1);
    // Strip query string (e.g. ?raw=12345)
    auto qpos = rawPath.find('?');
    if (qpos != std::string::npos) rawPath.resize(qpos);
    filename = HttpUtil::UrlDecode(rawPath);
    if (filename.empty()) return false;

    // Validate: resolved blob path must stay within the blob root.
    std::string blobPath = BlobPath(accountId, appId, filename);
    if (!FileUtil::IsPathWithin(g_blobRoot, blobPath)) {
        LOG("[HTTP] BLOCKED path traversal: %s (root=%s)", path, g_blobRoot.c_str());
        return false;
    }

    return true;
}

// handle one accepted connection: parse request line, dispatch GET or PUT
static void HandleClient(SOCKET client) {
    // Read headers until \r\n\r\n; cap at 64KB.
    static constexpr int MAX_HEADER_SIZE = 65536;
    std::vector<char> bufVec(MAX_HEADER_SIZE + 1);
    char* buf = bufVec.data();
    int total = 0;
    int headerEnd = -1;

    while (total < MAX_HEADER_SIZE) {
        int n = recv(client, buf + total, MAX_HEADER_SIZE - total, 0);
        if (n <= 0) break;
        total += n;
        buf[total] = '\0';

        char* found = strstr(buf, "\r\n\r\n");
        if (found) {
            headerEnd = (int)(found - buf) + 4;
            break;
        }
    }

    if (headerEnd < 0) {
        closesocket(client);
        return;
    }

    // parse request line: "METHOD /path HTTP/1.1\r\n"
    char method[16] = {};
    char path[2048] = {};
    if (sscanf(buf, "%15s %2047s", method, path) != 2) {
        closesocket(client);
        return;
    }

    // parse Content-Length from headers (case-insensitive)
    int64_t contentLength = -1;
    // Only search within header portion (before \r\n\r\n)
    const char* cl = stristr(buf, "\r\nContent-Length:");
    if (!cl || cl - buf > headerEnd) cl = nullptr;
    if (!cl) {
        cl = stristr(buf, "\nContent-Length:");
        if (cl && cl - buf > headerEnd) cl = nullptr;
    }
    if (cl) {
        char* endptr = nullptr;
        contentLength = _strtoi64(cl + (cl[0] == '\r' ? 17 : 16), &endptr, 10);
        if (endptr == cl + (cl[0] == '\r' ? 17 : 16)) contentLength = -1;
        if (contentLength < 0) contentLength = 0;
    }

    int bodyReceived = total - headerEnd;

    if (_stricmp(method, "PUT") == 0) {
        // Steam omits Content-Length for 0-byte files (LOCK, empty .log, etc.).
        // Treat missing header as 0 bytes rather than rejecting.
        if (contentLength < 0)
            contentLength = 0;

        // PUT /upload/<appId>/<filename>
        int64_t maxBytes = g_maxUploadBytes.load();
        if (maxBytes > 0 && contentLength > maxBytes) {
            LOG("[HTTP] PUT %s -> REJECTED: Content-Length %lld exceeds %lld byte cap",
                path, contentLength, maxBytes);
            const char* response =
                "HTTP/1.1 413 Payload Too Large\r\n"
                "Content-Length: 0\r\n"
                "Connection: close\r\n"
                "\r\n";
            send(client, response, (int)strlen(response), 0);
            closesocket(client);
            return;
        }

        uint32_t accountId = 0;
        uint32_t appId = 0;
        std::string filename;

        if (ParseBlobPath(path, "/upload/", accountId, appId, filename)) {
            // read the full body
            std::vector<uint8_t> bodyData;
            bodyData.reserve(contentLength > 0 ? (size_t)contentLength : 4096);

            // copy any body bytes already received with the headers
            if (bodyReceived > 0)
                bodyData.insert(bodyData.end(), buf + headerEnd, buf + headerEnd + bodyReceived);

            // read remaining body
            int64_t remaining = contentLength - bodyReceived;
            if (remaining > 0) {
                char chunk[65536];
                while (remaining > 0) {
                    int toRead = remaining < (int64_t)sizeof(chunk) ? (int)remaining : (int)sizeof(chunk);
                    int n = recv(client, chunk, toRead, 0);
                    if (n <= 0) break;
                    bodyData.insert(bodyData.end(), chunk, chunk + n);
                    remaining -= n;
                }
            }

            // Reject partial body - recv returned 0/-1 before all bytes arrived
            if (contentLength > 0 && (int64_t)bodyData.size() != contentLength) {
                LOG("[HTTP] PUT %s -> PARTIAL BODY (%zu of %lld bytes), rejecting",
                    path, bodyData.size(), (long long)contentLength);
                const char* errResponse =
                    "HTTP/1.1 400 Bad Request\r\n"
                    "Content-Length: 0\r\n"
                    "Connection: close\r\n"
                    "\r\n";
                send(client, errResponse, (int)strlen(errResponse), 0);
                shutdown(client, SD_SEND);
                closesocket(client);
                return;
            }

            // Decompress Steam's optional ZIP wrapper so blob storage holds raw content.
            std::vector<uint8_t> decompressed;
            if (TryDecompressZip(bodyData, decompressed)) {
                LOG("[HTTP] PUT %s -> decompressed %zu -> %zu bytes",
                    path, bodyData.size(), decompressed.size());
                bodyData = std::move(decompressed);
            }

            // ec overload: a thrown filesystem_error would leak the socket and wedge the slot.
            std::string blobPath = BlobPath(accountId, appId, filename);
            auto parent = FileUtil::Utf8ToPath(blobPath).parent_path();
            std::error_code mkEc;
            std::filesystem::create_directories(parent, mkEc);
            if (mkEc) {
                LOG("[HTTP] PUT %s -> create_directories '%s' FAILED: %s",
                    path, FileUtil::PathToUtf8(parent).c_str(), mkEc.message().c_str());
                const char* errResponse =
                    "HTTP/1.1 500 Internal Server Error\r\n"
                    "Content-Length: 0\r\n"
                    "Connection: close\r\n"
                    "\r\n";
                send(client, errResponse, (int)strlen(errResponse), 0);
                shutdown(client, SD_SEND);
                closesocket(client);
                return;
            }

            // Write blob to disk; stash in memory on failure.
            DWORD writeErr = 0;
            size_t storedSize = bodyData.size();
            if (!FileUtil::AtomicWriteBinary(blobPath, bodyData.data(), bodyData.size(), &writeErr)) {
                LOG("[HTTP] PUT %s -> disk write failed (err=%lu), holding %zu bytes in memory",
                    path, (unsigned long)writeErr, storedSize);
                std::lock_guard<std::mutex> lk(g_memBlobMtx);
                g_memBlobs[{accountId, appId, filename}] = std::move(bodyData);
            } else {
                // Disk write succeeded; clear any stale in-memory entry.
                std::lock_guard<std::mutex> lk(g_memBlobMtx);
                g_memBlobs.erase({accountId, appId, filename});
            }
            LOG("[HTTP] PUT %s -> stored %zu bytes (app %u, file %s)",
                path, storedSize, appId, filename.c_str());

            // return 200 OK (matches what Steam expects from Valve's storage)
            const char* response =
                "HTTP/1.1 200 OK\r\n"
                "Content-Length: 0\r\n"
                "Connection: close\r\n"
                "\r\n";
            send(client, response, (int)strlen(response), 0);
        } else {
            // unrecognized PUT path - drain and return 200 OK
            int64_t remaining = contentLength - bodyReceived;
            if (remaining > 0) {
                char drain[4096];
                while (remaining > 0) {
                    int chunk = remaining < (int64_t)sizeof(drain) ? (int)remaining : (int)sizeof(drain);
                    int n = recv(client, drain, chunk, 0);
                    if (n <= 0) break;
                    remaining -= n;
                }
            }
            LOG("[HTTP] PUT %s -> unrecognized path, drained %lld bytes", path, contentLength);
            const char* response =
                "HTTP/1.1 404 Not Found\r\n"
                "Content-Length: 0\r\n"
                "Connection: close\r\n"
                "\r\n";
            send(client, response, (int)strlen(response), 0);
        }
    } else if (_stricmp(method, "GET") == 0) {
        // GET /download/<appId>/<filename>
        uint32_t accountId = 0;
        uint32_t appId = 0;
        std::string filename;

        if (ParseBlobPath(path, "/download/", accountId, appId, filename)) {
            // Use RetrieveBlob which checks local cache first, then fetches from cloud on-demand
            bool found = false;
            std::vector<uint8_t> data = CloudStorage::RetrieveBlob(accountId, appId, filename, &found);

            if (found) {
                LOG("[HTTP] GET %s -> serving %zu bytes (app %u, file %s)",
                    path, data.size(), appId, filename.c_str());

                char respHeader[256];
                snprintf(respHeader, sizeof(respHeader),
                    "HTTP/1.1 200 OK\r\n"
                    "Content-Length: %zu\r\n"
                    "Connection: close\r\n"
                    "\r\n", data.size());
                send(client, respHeader, (int)strlen(respHeader), 0);

                size_t sent = 0;
                while (sent < data.size()) {
                    size_t toSend = std::min(data.size() - sent, (size_t)65536);
                    int n = send(client, reinterpret_cast<const char*>(data.data() + sent), (int)toSend, 0);
                    if (n <= 0) break;
                    sent += n;
                }
                LOG("[HTTP] GET %s -> sent %zu/%zu bytes", path, sent, data.size());
            } else {
                LOG("[HTTP] GET %s -> 404 blob not found (app %u, file %s)", path, appId, filename.c_str());
                const char* resp404 =
                    "HTTP/1.1 404 Not Found\r\n"
                    "Content-Length: 0\r\n"
                    "Connection: close\r\n"
                    "\r\n";
                send(client, resp404, (int)strlen(resp404), 0);
            }
        } else {
            LOG("[HTTP] GET %s -> 404 unrecognized path", path);
            const char* resp404 =
                "HTTP/1.1 404 Not Found\r\n"
                "Content-Length: 0\r\n"
                "Connection: close\r\n"
                "\r\n";
            send(client, resp404, (int)strlen(resp404), 0);
        }
    } else {
        // unrecognized method: drain body, return 405
        LOG("[HTTP] %s %s -> 405 method not allowed", method, path);
        int64_t remaining = contentLength > 0 ? contentLength - bodyReceived : 0;
        if (remaining > 0) {
            char drain[4096];
            while (remaining > 0) {
                int chunk = remaining < (int64_t)sizeof(drain) ? (int)remaining : (int)sizeof(drain);
                int n = recv(client, drain, chunk, 0);
                if (n <= 0) break;
                remaining -= n;
            }
        }
        const char* response =
            "HTTP/1.1 405 Method Not Allowed\r\n"
            "Content-Length: 0\r\n"
            "Connection: close\r\n"
            "\r\n";
        send(client, response, (int)strlen(response), 0);
    }

    shutdown(client, SD_SEND);
    closesocket(client);
}

// PID-of-source-port check via GetExtendedTcpTable; rejects anything not from our own process.
static bool IsConnectionFromSteam(SOCKET client) {
    // Get the peer's (client's) port
    sockaddr_in peer{};
    int peerLen = sizeof(peer);
    if (getpeername(client, (sockaddr*)&peer, &peerLen) != 0) return false;
    uint16_t peerPort = ntohs(peer.sin_port);

    DWORD myPid = GetCurrentProcessId();

    // Get the TCP connection table with PIDs
    DWORD tableSize = 0;
    GetExtendedTcpTable(nullptr, &tableSize, FALSE, AF_INET, TCP_TABLE_OWNER_PID_CONNECTIONS, 0);
    if (tableSize == 0) return false;

    std::vector<uint8_t> tableBuf(tableSize);
    if (GetExtendedTcpTable(tableBuf.data(), &tableSize, FALSE, AF_INET,
                            TCP_TABLE_OWNER_PID_CONNECTIONS, 0) != NO_ERROR) {
        return false;
    }

    auto* table = (MIB_TCPTABLE_OWNER_PID*)tableBuf.data();
    for (DWORD i = 0; i < table->dwNumEntries; i++) {
        auto& row = table->table[i];
        // Match: local port (peer's source port) and established state
        if (ntohs((uint16_t)row.dwLocalPort) == peerPort &&
            row.dwState == MIB_TCP_STATE_ESTAB) {
            if (row.dwOwningPid == myPid) return true;
            LOG("[HTTP] BLOCKED connection from PID %u (expected %u) on port %u",
                row.dwOwningPid, myPid, peerPort);
            return false;
        }
    }

    // Connection not found in table - race condition, reject to be safe
    return false;
}

static void AcceptLoop() {
    LOG("[HTTP] Accept loop started on port %u", g_port.load());
    while (g_running.load()) {
        // use select with a timeout so we can check g_running periodically
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(g_listenSock, &readfds);

        timeval tv;
        tv.tv_sec = 1;
        tv.tv_usec = 0;

        int sel = select(0, &readfds, nullptr, nullptr, &tv);
        if (sel <= 0) continue;

        SOCKET client = accept(g_listenSock, nullptr, nullptr);
        if (client == INVALID_SOCKET) continue;

        // Reject connections from other processes
        if (!IsConnectionFromSteam(client)) {
            closesocket(client);
            continue;
        }

        // SO_SNDTIMEO matters too: a stalled final send() can wedge a slot and saturate the thread cap.
        DWORD rcvTimeout = 30000; // 30s
        DWORD sndTimeout = 30000; // 30s
        setsockopt(client, SOL_SOCKET, SO_RCVTIMEO, (const char*)&rcvTimeout, sizeof(rcvTimeout));
        setsockopt(client, SOL_SOCKET, SO_SNDTIMEO, (const char*)&sndTimeout, sizeof(sndTimeout));

        // handle each connection on its own thread so parallel uploads don't queue up
        {
            std::lock_guard<std::mutex> lk(g_clientMtx);
            PruneClientThreads();

            // At the cap: backpressure instead of rejecting. A closed socket surfaces
            // as a Steam cloud error; waiting for a slot lets large bursts drain.
            int waitMs = 0;
            while (g_clientSlots.size() >= kMaxClientThreads && g_running.load() &&
                   waitMs < kAcceptBackpressureMaxMs) {
                std::this_thread::sleep_for(std::chrono::milliseconds(20));
                waitMs += 20;
                PruneClientThreads();
            }
            if (g_clientSlots.size() >= kMaxClientThreads) {
                LOG("[HTTP] Thread cap (%zu) still full after %dms, rejecting connection",
                    kMaxClientThreads, waitMs);
                closesocket(client);
                continue;
            }

            auto doneFlag = std::make_shared<std::atomic<bool>>(false);
            auto wrapper = [doneFlag](SOCKET s) {
                HandleClient(s);
                doneFlag->store(true);
            };
            try {
                g_clientSlots.push_back({std::thread(wrapper, client), doneFlag});
            } catch (...) {
                closesocket(client);
                LOG("[HTTP] Failed to create client thread");
            }
        }
    }
    LOG("[HTTP] Accept loop exited");
}

bool Start(const std::string& blobRoot, uint32_t accountId) {
    g_blobRoot = blobRoot;
    g_accountId.store(accountId);
    if (!g_blobRoot.empty() && g_blobRoot.back() != '\\')
        g_blobRoot += '\\';
    std::error_code rootEc;
    std::filesystem::create_directories(FileUtil::Utf8ToPath(g_blobRoot), rootEc);
    if (rootEc) {
        LOG("[HTTP] create_directories '%s' FAILED: %s (continuing -- later PUT writes will retry)",
            g_blobRoot.c_str(), rootEc.message().c_str());
    }
    LOG("[HTTP] Blob storage root: %s (accountId=%u)", g_blobRoot.c_str(), g_accountId.load());

    WSADATA wsa;
    if (WSAStartup(MAKEWORD(2, 2), &wsa) != 0) {
        LOG("[HTTP] WSAStartup failed: %d", WSAGetLastError());
        return false;
    }

    g_listenSock = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);
    if (g_listenSock == INVALID_SOCKET) {
        LOG("[HTTP] socket() failed: %d", WSAGetLastError());
        return false;
    }

    // bind to 127.0.0.1 with OS-assigned port
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    addr.sin_port = 0; // OS picks a free port

    if (bind(g_listenSock, (sockaddr*)&addr, sizeof(addr)) == SOCKET_ERROR) {
        LOG("[HTTP] bind() failed: %d", WSAGetLastError());
        closesocket(g_listenSock);
        g_listenSock = INVALID_SOCKET;
        return false;
    }

    // retrieve the assigned port
    sockaddr_in bound{};
    int boundLen = sizeof(bound);
    getsockname(g_listenSock, (sockaddr*)&bound, &boundLen);
    g_port.store(ntohs(bound.sin_port));

    if (listen(g_listenSock, SOMAXCONN) == SOCKET_ERROR) {
        LOG("[HTTP] listen() failed: %d", WSAGetLastError());
        closesocket(g_listenSock);
        g_listenSock = INVALID_SOCKET;
        return false;
    }

    g_running.store(true);
    g_acceptThread = std::thread(AcceptLoop);

    LOG("[HTTP] Server started on 127.0.0.1:%u", g_port.load());
    return true;
}

void Stop() {
    if (!g_running.load()) return;

    g_running.store(false);

    if (g_listenSock != INVALID_SOCKET) {
        closesocket(g_listenSock);
        g_listenSock = INVALID_SOCKET;
    }

    if (g_acceptThread.joinable())
        g_acceptThread.join();

    // Wait for in-flight client handlers to finish
    {
        std::lock_guard<std::mutex> lk(g_clientMtx);
        for (auto& slot : g_clientSlots) {
            if (slot.thread.joinable()) slot.thread.join();
        }
        g_clientSlots.clear();
    }

    WSACleanup();
    LOG("[HTTP] Server stopped");
}

void SetAccountId(uint32_t accountId) {
    g_accountId.store(accountId);
    LOG("[HTTP] Account ID set to %u", g_accountId.load());
}

void SetMaxUploadMB(int mb) {
    g_maxUploadBytes.store(mb > 0 ? static_cast<int64_t>(mb) * 1024LL * 1024LL : 0);
    if (mb > 0)
        LOG("[HTTP] Max upload cap set to %d MB", mb);
    else
        LOG("[HTTP] Max upload cap disabled (unlimited)");
}

uint16_t GetPort() {
    return g_port.load();
}

// Traversal guard for RPC-facing paths (mirror of ParseBlobPath's check).
static bool ValidateBlobPath(const std::string& blobPath) {
    if (!FileUtil::IsPathWithin(g_blobRoot, blobPath)) {
        LOG("[HTTP] BLOCKED path traversal (RPC): path='%s' root='%s'",
            blobPath.c_str(), g_blobRoot.c_str());
        return false;
    }
    return true;
}

bool HasBlob(uint32_t accountId, uint32_t appId, const std::string& filename) {
    {
        std::lock_guard<std::mutex> lk(g_memBlobMtx);
        if (g_memBlobs.count({accountId, appId, filename}))
            return true;
    }
    std::string path = BlobPath(accountId, appId, filename);
    if (!ValidateBlobPath(path)) return false;
    std::error_code ec;
    bool ex = std::filesystem::exists(FileUtil::Utf8ToPath(path), ec);
    return !ec && ex;
}

uint64_t GetBlobSize(uint32_t accountId, uint32_t appId, const std::string& filename) {
    {
        std::lock_guard<std::mutex> lk(g_memBlobMtx);
        auto it = g_memBlobs.find({accountId, appId, filename});
        if (it != g_memBlobs.end())
            return (uint64_t)it->second.size();
    }
    std::string path = BlobPath(accountId, appId, filename);
    if (!ValidateBlobPath(path)) return 0;
    std::error_code ec;
    auto sz = std::filesystem::file_size(FileUtil::Utf8ToPath(path), ec);
    return ec ? 0 : (uint64_t)sz;
}

std::vector<uint8_t> ReadBlob(uint32_t accountId, uint32_t appId, const std::string& filename) {
    {
        std::lock_guard<std::mutex> lk(g_memBlobMtx);
        auto it = g_memBlobs.find({accountId, appId, filename});
        if (it != g_memBlobs.end()) {
            std::vector<uint8_t> data = it->second;  // copy out
            // Retry disk write now that the lock is likely released.
            std::string blobPath = BlobPath(accountId, appId, filename);
            if (FileUtil::AtomicWriteBinary(blobPath, data.data(), data.size(), nullptr)) {
                g_memBlobs.erase(it);
            }
            return data;
        }
    }
    std::string path = BlobPath(accountId, appId, filename);
    if (!ValidateBlobPath(path)) return {};
    std::ifstream f(FileUtil::Utf8ToPath(path), std::ios::binary);
    if (!f) return {};
    return std::vector<uint8_t>(
        std::istreambuf_iterator<char>(f),
        std::istreambuf_iterator<char>()
    );
}

bool DeleteBlob(uint32_t accountId, uint32_t appId, const std::string& filename) {
    {
        std::lock_guard<std::mutex> lk(g_memBlobMtx);
        g_memBlobs.erase({accountId, appId, filename});
    }
    std::string path = BlobPath(accountId, appId, filename);
    if (!ValidateBlobPath(path)) return false;
    std::error_code ec;
    return std::filesystem::remove(FileUtil::Utf8ToPath(path), ec);
}

} // namespace HttpServer
