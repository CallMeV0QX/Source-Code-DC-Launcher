using CloudRedirect.Services.Providers;

namespace CloudRedirect.Services;

/// <summary>
/// Resolves a <see cref="CloudConfig"/> to the matching
/// <see cref="IUiCloudProvider"/> implementation. Returns <c>null</c> for
/// the local-only / unrecognized cases so the caller can short-circuit to
/// "nothing to do" without a switch of its own.
/// </summary>
internal static class UiCloudProviderFactory
{
    public static IUiCloudProvider? TryResolve(CloudConfig? config, Action<string>? log)
    {
        if (config == null || config.IsLocal) return null;
        return config.Provider switch
        {
            "gdrive"   => new CliUiCloudProvider("gdrive", log),
            "onedrive" => new CliUiCloudProvider("onedrive", log),
            "r2"       => new CliUiCloudProvider("r2", log),
            "s3"       => new CliUiCloudProvider("s3", log),
            "folder"   => new FolderUiCloudProvider(log, config.SyncPath!),
            _          => null,
        };
    }
}
